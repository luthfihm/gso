<?
	header("location:../index.php");
?>