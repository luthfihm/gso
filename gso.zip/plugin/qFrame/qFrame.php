<? /*
	*****************************************************************
	* 	frame name     : qFrame    			             		 	*
	*	author   	   : iadifriandi (iadifriandi@yahoo.co.id)		*
	*	build date     : 15/1/2011 						 			*
	*****************************************************************
	*/
	
	require_once("cnfg/qFrame.sql.php");
	require_once("tools/qFrame.tools.php");
	require_once("tools/qFrame.form.php");
	//require_once("tools/qFrame.js.php");
	require_once("tools/qFrame.grid.php");
	
?>