<? /*
	*****************************************************************
	* 	frame name     : qFrame.js	 								*
	*	author   	   : iadifriandi (iadifriandi@yahoo.co.id)		*
	*	build date     : 17/1/2011 						     	    *
	*****************************************************************
	*/
	class js{		
		function showAlertDialog($str){
			echo"javascript:alert('$str');";
		}
	}
?>