<div id="judul_page"><img src="image/point.png" border=0 align="absmiddle"> Info GANESHA SCIENCE OLYMPIAD</div>
<div id="box_isi" style="color:#333333">
    <div id="judul" style='padding:5px 0px 0px 2px'>
    <b>Ketentuan Ganesha Science Olympiad</b></div>
    <div id='box' style='border-top:none; border-right:none'>
    <table border="0" cellpadding="1">
    <tbody valign="top">
<tr valign="top"><td width="15px">1.</td><td>	Peserta adalah utusan dari sekolah yang telah mendapat rekomendasi dari Kepala Sekolah dan telah mendaftarkan diri sebagai peserta secara sah.</td></tr>
<tr valign="top"><td>2.</td><td>	Peserta adalah siswa / siswi yang sedang menempuh jenjang pendidikan SMP / MTs / Se-derajat yang berada di Pulau Jawa dan Bali.</td></tr>
<tr valign="top"><td>3.</td><td>	Perlombaan dilaksanakan perseorangan ( individu ).</td></tr>
<tr valign="top"><td>4.</td><td>	Sekolah diperbolehkan mengirim lebih dari 1 peserta untuk 1 bidang mata pelajaran dan tiap peserta harus mengisi formulir. </td></tr>
<tr valign="top"><td>5.</td><td>	Peserta diwajibkan memakai seragam OSIS / seragam sekolah yang bersangkutan dan bersepatu.</td></tr>
<tr valign="top"><td>6.</td><td>	Pelaksanaan acara dan lomba mengikuti susunan yang telah diberikan oleh panitia.</td></tr>
<tr valign="top"><td>7.</td><td>	Pengumuman pemenang lomba dan pemberian penghargaan akan dilaksanakan pada acara penutupan.</td></tr>
<tr valign="top"><td>8.</td><td>	Pendamping yang ikut bersama peserta dianggap menyetujui serta mematuhi seluruh ketentuan yang telah ditetapkan oleh panitia.</td></tr>
</tbody>
    </table>
    </div>
</div>
<div id="box_isi" style="color:#333333">
    <div id="judul" style='padding:5px 0px 0px 2px'>
    <b>Prosedur Pendaftaran</b></div>
    <div id='box' style='border-top:none; border-right:none'>
    <table border="0" cellpadding="1">
		<tr><td width="15px">1.</td><td> Peserta mengisi Form Pendaftaran Online. </td></tr>
		<tr><td>2.</td><td> Peserta men-download dan mencetak Biodata. </td></tr>
		<tr><td>3.</td><td> Peserta melakukan verifikasi pada saat sebelum lomba dilaksanakan (Biodata yang telah disertakan). </td></tr>
    </table>
    </div>
</div>
<div id="box_isi" style="color:#333333">
    <div id="judul" style='padding:5px 0px 0px 2px'>
    <b>Jadwal Pelaksanaan</b></div>
    <div id='box' style='border-top:none; border-right:none'>
    <table border="0" cellpadding="1">
		<tr><td>Hari/tanggal</td><td>: Minggu, 2 Oktober 2011 </td></tr>
		<tr><td>Waktu</td><td>: 09.00 - Selesai</td></tr>
		<tr><td>Tempat</td><td>: Kampus SMA N 3 Semarang</td></tr>
    </table>
    </div>
</div>
<div id="box_isi" style="color:#333333">
    <div id="judul" style='padding:5px 0px 0px 2px'>
    <b>Kontribusi Peserta</b></div>
    <div id='box' style='border-top:none; border-right:none'>
    Setiap peserta dikenakan biaya kontribusi untuk administrasi sebesar <b>Rp 75.000,00 (tujuh puluh lima ribu rupiah)</b>. Pembayaran dapat dibayar langsung pada saat daftar ulang atau via transfer<br />
    <table border="0" cellpadding="1">
		<tr><td>No. Rekening</td><td>:</td><td>0205047367 - BNI CABANG KARANGAYU</td></tr>
		<tr><td>atas nama</td><td>:</td><td>FIQIE ULYA SIDIASTAHTA</td></tr>
    </table>
    </div>
</div>
<div id="box_isi" style="color:#333333">
    <div id="judul" style='padding:5px 0px 0px 2px'>
    <b>Konfirmasi Pembayaran</b></div>
    <div id='box' style='border-top:none; border-right:none'>
    	Bagi yang melakukan pembayaran dengan transfer harap mengirim konfirmasi ke email <b> gsosmaga@yahoo.com</b> dengan mencantumkan :
        <table border="0" cellpadding="1">
        <tr><td width="15px">1.</td><td> Nama, Asal Sekolah, Nomor Peserta</td></tr>
        <tr><td>2.</td><td> Jumlah uang yang ditransfer</td></tr>
        <tr><td>3.</td><td> Tanggal transfer</td></tr>
        <tr><td valign="top">4.</td><td> Nama pengirim (Nama pemegang rekening jika antar rekening bank, jika via setoran tunai di bank cantumkan nama pengirim yang ditulis di slip setoran)</td></tr>
        </table>
    </div>
</div>