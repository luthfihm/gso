<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>_menu</title>
<style type="text/css">
	a{text-decoration:underline;
	color:#006699;}
</style>
</head>
<body>
<div id="judul_page"><table border=0 ><tr><td><img src="image/point.png" border=0 align="absmiddle"></td><td width="450px"> Selamat Datang</td><td width="300px" align="right">
<div style="float: right;">
<div style="float: left; margin: 1px 10px 0px 0px">
<a name="fb_share" type="button_count" href="http://www.facebook.com/sharer.php">Share</a><script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script></div><div style="float: right;">
<a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></div></div>
</td></tr></table>
</div>

<div id="box_isi" style="color:#333333;">
<div style="font-size:15px;">
<img src="image/pamflet.jpg" style="float: left; margin: 5px 10px 10px 0px;" height="250px"/>
<br />
	<div align="center" style=" font-size:24px;"><strong>GSO (Ganesha Science Olympiad)<br />
    "Elevate Your Brainitivity"</strong></div>
    <br />
    <p align="justify">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    Seiring dengan berkembangnya zaman, ilmu pengetahuan khususnya sains juga
makin berkembang. Kebutuhan manusia semakin kompleks dengan adanya perkembanganm sains. Kebutuhan manusia tersebut dapat terpenuhi dengan lebih praktis dan efisien. Tidak hanya diterapkan secara teori saja, sains juga diterapkan dalam berbagai praktek di kehidupan sehari-hari. Selain itu manusia juga mulai menciptakan teknologi berbasis sains yang bermanfaat untuk meningkatkan taraf hidup mereka.<br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Mengingat betapa pentingnya sains dalam setiap aspek kehidupan manusia, OSIS SMA Negeri 3 Semarang bersama dengan Menuju Olimpiade Sains Indonesia (MOSI) SMA Negeri 3 Semarang merasa perlu mengadakan sebuah kegiatan yang dapat menumbuhkan minat para pelajar khususnya siswa-siswi SMP terhadap bidang sains. Salah satunya adalah dengan mengadakan olimpiade sains antar SMP tingkat Jawa-Bali yang bertajuk Ganesha Science Olympiad.<br /><br />

GSO mencakup 4 bidang pelajaran antara lain <b>Biologi, Fisika, Matematika, Komputer.</b><br /><br />

Anda dapat mendaftar secara online melalui website ini paling lambat <b>30 September 2011.</b><br /><br />

Untuk info lebih lengkap silakan download Petunjuk Pelaksanaan Ganesha Science Olympiad 2011 dengan meng-klik link di bawah ini<br />
<table>
                    <tr><td><a href="include/petunjuk_pelaksanaan_gso.pdf" target="_blank"><img src="image/logo_pdf.png" height="50px" border="0"  /></a></td><td><a href="include/petunjuk_pelaksanaan_gso.pdf" target="_blank" ><h3>Download Petunjuk Pelaksanaan GSO</h3></a></td></tr></table>
    </p>
    </div>
</div>
<br />
</body>
</html>
