<div id="judul_page"><table border=0><tr><td><img src="image/info_icon.png" border=0 align="absmiddle"></td><td>Kontak Ganesha Sience Olympiad</td></tr></table></div>
			<div id="box">
					<p style="padding:0px 0px 0px 10px; font-size:14px;">
						Untuk info lebih lanjut tentang pendafataran, silahkan hubungi kami di :<br />
                        - 	(024) 35544287 <br />
                        -	(024) 35544291 <br />
                        -	e-mail : gsosmaga@yahoo.com <br /><br />
                        
                        Contact Person<br />
                        -	Arlita (085726866221)<br />
                        -   Ana (08562899109)
					</p>
				</div>