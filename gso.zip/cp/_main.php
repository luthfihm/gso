<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>_menu</title>
<style type="text/css">
	a{text-decoration:none;
	color:#006699;}
	a:hover{text-decoration:underline; }
</style>
    <script type="text/javascript" src="../plugin/jq/jquery-1.3.2.js"></script>
    <script type="text/javascript" src="../plugin/jq/ui/effects.core.js"></script>
    <script type="text/javascript" src="../plugin/jq/ui/effects.bounce.js"></script>
    <script type="text/javascript">
		function runEffect(){
			$("#animasi").effect("bounce", { distance: 20});
		};
		function runEffect1(){
			$("#animasi1").effect("bounce", { distance: 20});
		};
		function runEffect2(){
			$("#animasi2").effect("bounce", { distance: 20});
		};
		function runEffect3(){
			$("#animasi3").effect("bounce", { distance: 20});
		};
    </script>
</head>
<body>
<h3> &nbsp;Welcome to administration page, use this page for configuration your system.</h3>
<table align="center" cellpadding="1" cellspacing="1" style="margin-top:50px">
	<tr>
		<td><a href="main_menu.php?view=biologi"><img src="../image/content.png" border="0" height="100" width="110" title="Biologi" onmouseover="runEffect();" id="animasi"/></a></td>
        <td colspan="10">&nbsp;</td>
        <td><a href="main_menu.php?view=fisika"><img src="../image/content.png" border="0" height="100" width="110" title="Fisika" onmouseover="runEffect2();" id="animasi2"/></a></td>
        <td colspan="10">&nbsp;</td>
        <td><a href="main_menu.php?view=matematika"><img src="../image/content.png" border="0" height="100" width="110" title="Matematika" onmouseover="runEffect3();" id="animasi3"/></a></td>
        <td colspan="10">&nbsp;</td>
        <td><a href="main_menu.php?view=komputer"><img src="../image/content.png" border="0" height="100" width="110" title="Komputer" onmouseover="runEffect4();" id="animasi4"/></a></td>
        <td colspan="10">&nbsp;</td>
		<td><a href="main_menu.php?view=admin"><img src="../image/user_login-icon.gif" border="0" title="Administrator" onmouseover="runEffect5();" id="animasi5"/></a></td>
	</tr>
	<tr>
		<td align="center"><a href="main_menu.php?view=biologi">Biologi</a></td>
        <td colspan="10">&nbsp;</td>
        <td align="center"><a href="main_menu.php?view=fisika">Fisika</a></td>
        <td colspan="10">&nbsp;</td>
        <td align="center"><a href="main_menu.php?view=matematika">Matematika</a></td>
        <td colspan="10">&nbsp;</td>
        <td align="center"><a href="main_menu.php?view=komputer">Komputer</a></td>
        <td colspan="10">&nbsp;</td>
		<td align="center"><a href="main_menu.php?view=admin">Administrator</a></td>
	</tr>
</table>
</body>
</html>
